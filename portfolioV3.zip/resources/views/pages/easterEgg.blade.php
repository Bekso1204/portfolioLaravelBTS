<style contenteditable
style="display: block;
white-space: pre;"
>

</style>