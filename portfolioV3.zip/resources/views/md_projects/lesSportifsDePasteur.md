---
title: Les Sportifs De Pasteur
file_name: lesSportifsDePasteur
img: /assets/lesSportifsDePasteur.jpg
img_alt: Aperçu de la page d'acceuil de notre site
description: |
  Nous devions réaliser en groupe un site internet qui serait ensuite réutilisé pour nos professeur
  pour pouvoir gérer les inscriptions au sport du mardi soir pour les étudiants dans le supérieur
tags:
  - PHP
  - HTML
  - CSS
  - Javascript
  - MySQL
---

# Présentation du projet

Nous devions réaliser en groupe un site internet qui serait ensuite réutilisé pour nos professeur pour pouvoir gérer les inscriptions au sport du mardi soir pour les étudiants dans le supérieur. Ce projet avait une durée limite de 3 mois, de fin janvier à début mai. 

# Fonctionnalités

Il était composé d'une page d'acceuil identique pour les élèves et les administrateurs, la barre de navigation, elle devait changer. On avait les boutons de création de sports et de séances et le boutn de retour au menu pour les admin, pour les élèves, il y avait le bouton menu et aussi les boutons pour s'inscrire et voir ses inscriptions. Chacun pouvait modifier les données de son profil (login, mot de passe, adresse mail et même photo de profil). Du côté admin, chaque sport créé pouvait être ajouté à une séance, une séance contenait un titre, une date, une heure de début, une heure de fin et un ou plusieurs sports. Les élèves eux pouvaient s'inscrirent en choisissant le sport qu'ils souhaitaient faire.

# Points positifs de ce projet

Ce projet m'a aidé à monter en compétences. En effet, cela a été mon premier gros projet et m'a permis de travailler en équipe et aussi de respecter des dates de livraison de lot, nous avons éssayé de réaliser le projet comme nous l'avions découpé. Lors de ce projet j'ai pu m'améliorer dans l'utilisation du langage PHP, codé à la main sans framework, je me suis aussi amélioré en HTML, CSS et Javascript avec l'utilisation de Tailwind et Bootstrap.

# Points négatifs du projet

Nous avons essayé de respecter les dates de livraison des lots mais nous n'avons pas réussi à le terminer à temps, mais nous avions assez bien avancé sur sa réalisation, nous l'avions terminé à 80%.