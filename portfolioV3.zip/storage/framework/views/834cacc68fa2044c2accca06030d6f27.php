<div class="nav-bar">
    <a href="#" class="logo">ALEXIAN.</a>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="navbar">
        <ul>
            <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(Request::routeIs('home') ? 'active' : ''); ?>">Home</a></li>
            <li><a href="<?php echo e(route('projects')); ?>" class="<?php echo e(Request::routeIs('projects') ? 'active' : ''); ?>">Projects</a></li>
            <li><a href="<?php echo e(route('about')); ?>" class="<?php echo e(Request::routeIs('about') ? 'active' : ''); ?>">About</a></li>
            <li><a href="#">Skills</a></li>
            <li><a href="#">Technical monitoring</a></li>
        </ul>
    </nav>
    </label>
</div>

<style>
    /** responsive navbar */
    *{
        margin: 0;
        padding: 0;
        text-decoration: none;
        list-style: none;
        font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        box-sizing: border-box;
    }
    .nav-bar {
        display: block;
        width: 100%;
        height: 80px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 100px;
        background: #11101b;
    }
    .logo{
        font-size: 28px;
        color: #fefefe;
    }
    .hamburger{
        display: none;
    }
    .navbar{
        transition: 0.2s;
        margin: 0 5px;
    }
    .navbar ul {
        display: flex;
    }
    .navbar ul li a{
        display: block;
        color: #fefefe;
        font-size: 20px;
        padding: 10px 25px;
        border-radius: 50px;
        transition: 0.2s;
        margin: 0 5px;
    }
    .navbar ul li a:hover{
        color :#11101b;
        background: #fefefe;
    }
    .navbar ul li a.active{
        color: #11101b;
        background: #fefefe;
    }
    @media only screen and (max-width: 1300px){
        .navbar ul li a {
            padding: 10px 20px;
        }
    }
    @media only screen and (max-width: 1250px){
        .navbar ul li a {
            padding: 10px 17px;
        }
    }
    @media only screen and (max-width: 1200px){
        .navbar ul li a {
            padding: 10px 15px;
        }
    }
    @media only screen and (max-width: 1150px){
        .navbar ul li a {
            padding: 10px 13px;
        }
    }
    @media only screen and (max-width: 1100px){
        .navbar ul li a {
            padding: 10px 10px;
        }
    }
    @media only screen and (max-width: 1050px){
        .navbar ul li a {
            padding: 10px 7px;
        }
    }
    @media only screen and (max-width: 1000px){
        .navbar ul li a {
            padding: 10px 5px;
        }
    }
    @media only screen and (max-width: 900px){
        .hamburger{
            display: block;
            cursor: pointer;
        }
        .hamburger .line{
            width: 30px;
            height: 3px;
            background: #fefefe;
            margin: 6px 0;
        }
        .navbar{
            height: 0px;
            position: absolute;
            top: 80px;
            left: 0;
            right: 0;
            width: 100vw;
            background: #11101b;
            transition: 0.5s;
            overflow: hidden;
        }
        .navbar.active{
            height: 450px;        
        }
        .navbar ul{
            display: block;
            width: fit-content;
            margin: 80px auto 0 auto;
            text-align: center;
            transition: 0.5s;
            opacity: 0;
        }
        .navbar.active ul{
            opacity: 1;        
        }
        .navbar ul li a{
            margin-bottom: 12px;
        }
    }
</style>
<script>
    const navbar = document.querySelector('.navbar'); 
    const hamburger = document.querySelector('.hamburger')

    hamburger.addEventListener('click', () => {
    navbar.classList.toggle('active');
});
</script><?php /**PATH C:\laragon\www\portfolioLaravel\resources\views/templates/navbar.blade.php ENDPATH**/ ?>