
<?php $__env->startSection('content'); ?>

<main class="page">
    <header class="head">
        <h1 class="title">
            <?php echo e($project['title']); ?>

        </h1>
    </header>
    <?php $__currentLoopData = $project['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <span class="project-tag"><?php echo e($tag); ?></span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="project-container">
        <?php $__currentLoopData = $project['sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1 class="project-part-title"><?php echo e($title); ?></h2>
        <p class="project-part-paragraph"><?php echo e($text); ?></p>
        <br><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portfolioLaravel\resources\views/pages/projects/show.blade.php ENDPATH**/ ?>