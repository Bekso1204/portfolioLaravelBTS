
    
<style>
body{
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    height: 100vh;
    width: 100vw;
    margin: 0;
    display: flex;
    flex-direction: column;
}
</style>

<?php echo $__env->make('templates.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portfolioLaravel\resources\views/pages/acceuil.blade.php ENDPATH**/ ?>