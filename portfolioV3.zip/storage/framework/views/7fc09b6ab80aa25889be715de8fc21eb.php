
<?php $__env->startSection('content'); ?>
<main class="page">
    <header class="head">
        <h1 class="title">
            Mes projets
        </h1>
        <p class="desc">
            Découvrez les projets que j'ai pu réaliser durant mon parcours scolaire
        </p>
    </header>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="projects-container">
        <h2 class="project-title"><?php echo e($project['title']); ?></h2>
        <div class="flex-container">
            <img src="<?php echo e($project['photo']); ?>" alt="<?php echo e($project['photo_alt']); ?>" class="project-img">
            <div class="desc-tags-container">
                <p class="project-desc"><?php echo e($project['description']); ?></p>
                <?php $__currentLoopData = $project['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="project-tag"><?php echo e($tag); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a href="<?php echo e(route('project', [$project['slug']])); ?>" class="project-more">Voir plus <i class="ri-arrow-right-line"></i></a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main>
<?php echo \Illuminate\View\Factory::parentPlaceholder('content'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portfolioLaravel\resources\views/pages/projects/index.blade.php ENDPATH**/ ?>